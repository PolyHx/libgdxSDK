package io.polyhx;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.Input;
import io.polyhx.engine.entities.AnimatedSpriteEntity;
import io.polyhx.engine.entities.Label;
import io.polyhx.engine.entities.SpriteEntity;
import io.polyhx.engine.utils.Clock;
import io.polyhx.engine.utils.Constants;
import io.polyhx.engine.utils.Keybord;
import io.polyhx.engine.utils.Mouse;
import java.util.ArrayList;
import java.util.Random;
import java.util.Vector;

class CustomButton {
    Label lb;
    Vector2 bounds;

    CustomButton(String text, Vector2 position, Color color){
        lb = new Label();
        lb.setText(text);
        lb.setPosition(position);
        lb.setColor(color);
        bounds = new Vector2(position.x + 70 * text.length(),position.y - 63);
    }

    void setScale(float scale){
        lb.setFontScale(scale);
    }

    void draw(Batch batch){
        lb.draw(batch);
    }

    boolean isClicked(){
        Vector2 m_p = Mouse.getPosition();
        boolean cond1 = (m_p.x >= lb.getPosition().x && m_p.y >= bounds.y);
        boolean cond2 = (m_p.x <= bounds.x && m_p.y <= lb.getPosition().y);
        return (cond1 && cond2);
    }
}

class Obstacle{
    Vector<SpriteEntity> obstacle;
    Obstacle(){
        Random rand = new Random();
        rand.setSeed(System.currentTimeMillis());
        obstacle = new Vector<SpriteEntity>();
        int numb = rand.nextInt(2) + 1;
        for(int i = 0; i< numb; ++i) {
            obstacle.add(new SpriteEntity("..\\assets\\obstacle.png"));
            obstacle.get(i).setOrigin(new Vector2(0,0));
            obstacle.get(i).setPosition(new Vector2(1024-65,0 + i*65));
            obstacle.get(i).setVelocity(new Vector2(-100,0));
        }
    }

    public boolean checkCollision(Player player){
        Rectangle rect;
        for(SpriteEntity sprite: obstacle){
            rect = new Rectangle(sprite.getBounds().x,sprite.getBounds().y,20,20);
            if(sprite.getBounds().overlaps(player.getBounds())){
                return true;
            }
        }
        return false;
    }

    public float getXPosition(){
        return obstacle.get(0).getPosition().x;
    }

    public int getScore(){
        return obstacle.size();
    }

    public void draw(Batch batch) {
        for (SpriteEntity obj: obstacle) {
            obj.draw(batch);
        }
    }
}

class Player {
    AnimatedSpriteEntity sprite;
    float jumpPower = 150;
    boolean isJumping = false;
    boolean isCharging = false;
    ArrayList<SpriteEntity> lives;

    Player() {
        sprite = new AnimatedSpriteEntity("..\\assets\\character.png",2,8);
        sprite.setOrigin(new Vector2(0,0));
        sprite.setPosition(new Vector2(0,0));
        setLives(3);
    }

    public void setLives(int nbOfLives) {
        lives = new ArrayList<SpriteEntity>();
        for(int i = 0; i < nbOfLives; ++i) {
            lives.add(new SpriteEntity("..\\assets\\life.png"));
            lives.get(i).setOrigin(new Vector2(0,0));
            lives.get(i).setPosition(new Vector2(10+i*65,655));
        }
    }

    void draw(Batch batch) {
        sprite.draw(batch);
        for(SpriteEntity life: lives) {
            life.draw(batch);
        }
    }

    public void checkJump(float delta){
        boolean leftMouseButtonClicked = Mouse.isButtonClicked(Constants.MOUSELEFT);
        if(leftMouseButtonClicked && isCharging) {
            jumpPower += 10;
            if(jumpPower >= 300)
                jumpPower = 300;
        }
        if(leftMouseButtonClicked && !isJumping) {
            isCharging = true;
        }
        if(isCharging && !leftMouseButtonClicked){
            sprite.setVelocity(new Vector2(0,jumpPower));
            isCharging = false;
            isJumping = true;
            jumpPower = 150;
        }
        if (isJumping) {
            sprite.setVelocity(new Vector2(sprite.getVelocity().x, sprite.getVelocity().y - delta*198.1f));
            if (sprite.getPosition().y < 0) {
                isJumping = false;
                sprite.setPosition(new Vector2(Mouse.getPosition().x - 55,0));
                sprite.setVelocity(new Vector2(0,0));
            }
        }
    }

    public Rectangle getBounds(){
        return new Rectangle(sprite.getBounds().x + 20,sprite.getBounds().y,50,60);
    }

    public boolean loseALife(){
        if(lives.size() > 0) {
            lives.remove(lives.size()-1);
            if(lives.size() == 0) return false;
            return true;
        }
        return false;
    }
}

public class Game {
    SpriteEntity background;
    SpriteEntity credits;
    CustomButton startButton;
    CustomButton creditsButton;
    CustomButton exitCreditsButton;
    ArrayList<Obstacle> obstacles;
    Player player = new Player();
    Clock obstacleClock;
    Clock timer;
    Label scoreLabel;
    Label timeLabel;
    Label bestScoreLabel;
    int score;
    int bestScore;
    int gameState;

    public Game() {
        creditsButton = new CustomButton("CREDITS",new Vector2(700,700),Color.RED);
        creditsButton.setScale(-0.5f);
        exitCreditsButton = new CustomButton("Exit", new Vector2(850,50),Color.RED);
        exitCreditsButton.setScale(-0.5f);
        startButton = new CustomButton("START",new Vector2(330,200), Color.RED);
        background = new SpriteEntity("..\\assets\\scrollingBackground.png");
        credits = new SpriteEntity("..\\assets\\credits.png");

        obstacleClock = new Clock();
        scoreLabel = new Label();
        scoreLabel.setPosition(new Vector2(10,640));
        bestScoreLabel = new Label();
        bestScoreLabel.setPosition(new Vector2(300,400));
        timer = new Clock();
        timeLabel = new Label();
        timeLabel.setPosition(new Vector2(600,700));
        bestScore = 0;
        prepareMenu();
    }

    public void prepareMenu() {
        background.setOrigin(new Vector2(0,0));
        background.setPosition(new Vector2(0,0));
        background.setVelocity(new Vector2(0,0));
        bestScoreLabel.setText("Best " + bestScore);
        credits.setOrigin(new Vector2(0,1300));
        credits.setPosition(new Vector2(0,0));
        gameState = 0;
    }

    public void startNewGame(){
        player.setLives(3);
        background.setVelocity(new Vector2(-100,0));
        obstacleClock.restart();
        timer.restart();
        score = 0;
        scoreLabel.setText("" + score);
        timeLabel.setText("0m0s");
        obstacles = new ArrayList<Obstacle>();
    }

    public void act(float delta) {
        Vector2 m_p = Mouse.getPosition();
        if(gameState == 0){
            if (Mouse.isButtonClicked(Constants.MOUSELEFT)){
                if(startButton.isClicked()) {
                    gameState = 1;
                    startNewGame();
                }
                else if(creditsButton.isClicked()){
                    gameState = 2;
                    credits.setVelocity(new Vector2(0,50));
                }
            }
        }
        else if (gameState == 1){
            player.sprite.setPosition(new Vector2(Mouse.getPosition().x - 55,player.sprite.getPosition().y));
            player.checkJump(delta);
            addObstacles();
            checkCollision();
        }
        else if(gameState == 2){
            if (Mouse.isButtonClicked(Constants.MOUSELEFT)){
                 if(exitCreditsButton.isClicked()){
                    gameState = 0;
                    prepareMenu();
                }
            }
        }

    }

    public void resetGame(){
        if(bestScore < score) {
            bestScore = score;
        }
        prepareMenu();
    }

    public void draw(Batch batch) {
        background.draw(batch);
        if (gameState == 0){
            startButton.draw(batch);
            bestScoreLabel.draw(batch);
            creditsButton.draw(batch);
        }
        else if (gameState == 1){
            drawGame(batch);
        }
        else if(gameState == 2){
            credits.draw(batch);
            exitCreditsButton.draw(batch);
        }

    }

    public void drawGame(Batch batch){
        scoreLabel.draw(batch);
        int min = (int)(timer.getElapsedTime()/60);
        int sec = (int)timer.getElapsedTime()%60;
        String minutes = (min <= 9) ? "0" + min : "" + min;
        String seconds = (sec <= 9) ? "0" + sec : "" + sec;
        timeLabel.setText(minutes + "m" + seconds +"s");
        timeLabel.draw(batch);
        Obstacle toRemove = null;
        for (Obstacle obs: obstacles) {
            obs.draw(batch);
            if(obs.getXPosition() <= -65){
                toRemove = obs;
            }
        }
        if(toRemove != null) {
            obstacles.remove(toRemove);
            score += toRemove.getScore();
            scoreLabel.setText("" + score);
        }
        player.draw(batch);
        if (Math.abs(background.getPosition().x) >=  3582 - 1024 ){
            background.setPosition(new Vector2(0,0));
        }
    }

    public void checkCollision(){
        Obstacle ob = null;
        for (Obstacle obstacle: obstacles) {
            if(obstacle.checkCollision(player)){
               if(player.loseALife())
                    ob = obstacle;
               else {
                   resetGame();
               }
            }
        }
        if (ob != null) obstacles.remove(ob);
    }

    public void addObstacles(){
        if(obstacleClock.getElapsedTime() >= 4f){
            obstacles.add(new Obstacle());
            obstacleClock.restart();
        }
    }
}